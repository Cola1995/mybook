create function f1(i1 int, i2 int)
  returns int
  BEGIN
    declare num int;
    set num = i1 + i2;
    return(num);
END;

