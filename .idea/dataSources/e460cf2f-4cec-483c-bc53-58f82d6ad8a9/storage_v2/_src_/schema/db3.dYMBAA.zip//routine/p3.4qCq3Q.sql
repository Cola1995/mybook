create procedure p3(IN n1 int, OUT n2 int)
  BEGIN
				set n2 = 123123;
				select * from student where sid > n1;
			END;

