create procedure p6()
  begin 
				declare row_id int; -- 自定义变量1  
				declare row_num int; -- 自定义变量2 
				declare done INT DEFAULT FALSE;
				declare temp int;
				
				declare my_cursor CURSOR FOR select id,num from A;
				declare CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
				
				
				
				open my_cursor;
					xxoo: LOOP
						fetch my_cursor into row_id,row_num;
						if done then 
							leave xxoo;
						END IF;
						set temp = row_id + row_num;
						insert into B(number) values(temp);
					end loop xxoo;
				close my_cursor;
				
				
			end;

