create trigger aa
  before INSERT
  on student
  for each row
  BEGIN
 INSERT into teacher (tname) VALUES (new.sname);
 END;

