create view v1 as
  select `db3`.`score`.`sid`        AS `sid`,
         `db3`.`score`.`student_id` AS `student_id`,
         `db3`.`score`.`course_id`  AS `course_id`,
         `db3`.`score`.`num`        AS `num`
  from `db3`.`score`;

