create view v2 as
  select `db3`.`student`.`sid`      AS `sid`,
         `db3`.`student`.`gender`   AS `gender`,
         `db3`.`student`.`class_id` AS `class_id`,
         `db3`.`student`.`sname`    AS `sname`,
         `db3`.`class`.`cid`        AS `cid`,
         `db3`.`class`.`caption`    AS `caption`
  from (`db3`.`student` left join `db3`.`class` on ((`db3`.`student`.`class_id` = `db3`.`class`.`cid`)));

