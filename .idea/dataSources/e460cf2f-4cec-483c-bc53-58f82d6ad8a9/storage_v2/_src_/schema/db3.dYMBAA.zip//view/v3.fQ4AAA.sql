create view v3 as
  select `db3`.`score`.`sid`         AS `sid`,
         `db3`.`score`.`student_id`  AS `student_id`,
         `db3`.`score`.`course_id`   AS `course_id`,
         `db3`.`score`.`num`         AS `num`,
         `db3`.`course`.`cid`        AS `cid`,
         `db3`.`course`.`cname`      AS `cname`,
         `db3`.`course`.`teacher_id` AS `teacher_id`
  from (`db3`.`score` left join `db3`.`course` on ((`db3`.`score`.`course_id` = `db3`.`course`.`cid`)));

