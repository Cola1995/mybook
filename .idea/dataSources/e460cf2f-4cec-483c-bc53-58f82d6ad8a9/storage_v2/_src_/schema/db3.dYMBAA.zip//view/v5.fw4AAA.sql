create view v5 as
  select `db3`.`score`.`student_id` AS `student_id`,
         `db3`.`score`.`course_id`  AS `course_id`,
         `db3`.`student`.`sname`    AS `sname`
  from ((`db3`.`score` left join `db3`.`course` on ((`db3`.`score`.`course_id` =
                                                     `db3`.`course`.`cid`))) left join `db3`.`student` on ((
    `db3`.`score`.`student_id` = `db3`.`student`.`sid`)));

